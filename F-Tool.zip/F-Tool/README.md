<p align="center"><img src="https://raw.githubusercontent.com/FDc0d3/F-Tool/main/screenshot/Screenshot_2022_0815_164706.png" width="400px" height="200px" alt="picture"></p>
<h1 align="center">F-Tool - Powerful DDoS Script With 9 Methods</h1>
<em><h5 align="center">Programming Language - Python 3</h5></em>

<p align="center">Please Don't Attack government websites.</p>

# Features And Methods

* Layer4

* VSE: UDP Valve Source Engine specific flood
* SYN: TCP SYN flood
* TCP: TCP junk flood
* UDP:  UDP junk flood
* HTTP: HTTP GET request flood

* Layer7

* SOCKET: Slow HTTP/1.1 socket flood
* HTTP1: TLS HTTP/1.1 GET flood
* HTTP2: TLS HTTP/2 GET flood
* CRINGE: Powerful Method Target Maybe die from Cringe

# Installation

* Please use spoofed server for the best experience.

* ```git clone https://github.com/FDc0d3/F-Tool.git```
* ```cd F-Tool; sh install.sh```

* Install CentOS

* ```cd F-Tool; sh installCentOS.sh```

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/FDc0d3/F-Toolhit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)

# Old Proofs

<p align="center"><img src="https://raw.githubusercontent.com/FDc0d3/F-Tool/main/screenshot/IMG_20220803_220812.jpg" width="500px" height="400px" alt="picture"></p>
<p align="center"><img src="https://raw.githubusercontent.com/FDc0d3/F-Tool/main/screenshot/Screenshot_2022_0803_141022.png" width="400px" height="400px" alt="picture"></p>
<p align="center"><img src="https://raw.githubusercontent.com/FDc0d3/F-Tool/main/screenshot/IMG_20220803_225424.jpg" width="500px" height="400px" alt="picture"></p>
<p align="center"><img src="https://raw.githubusercontent.com/FDc0d3/F-Tool/main/screenshot/Screenshot_2022_0803_225814.png" width="500px" height="400px" alt="picture"></p>

# contact dev
* Telegram: @FDc0d3

# Donation
* New[BTC]Wallet: ```32FGCnt4uwkkByWuH8V4qyCSfynm1iVsmB```




